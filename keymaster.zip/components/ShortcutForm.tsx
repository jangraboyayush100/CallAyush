import React, { useState, useEffect, useMemo } from 'react';
import { X, Save, Globe, Type, Smartphone, AlertCircle, Check } from 'lucide-react';
import { Shortcut, ShortcutFormData } from '../types';
import KeyRecorder from './KeyRecorder';

interface ShortcutFormProps {
  initialData?: Shortcut;
  existingShortcuts: Shortcut[];
  onSubmit: (data: ShortcutFormData) => void;
  onCancel: () => void;
}

const COMMON_APPS = [
  { name: 'Phone', scheme: 'tel:', placeholder: 'tel:1234567890' },
  { name: 'Messages (SMS)', scheme: 'sms:', placeholder: 'sms:1234567890' },
  { name: 'Email', scheme: 'mailto:', placeholder: 'mailto:example@gmail.com' },
  { name: 'WhatsApp', scheme: 'whatsapp://', placeholder: 'whatsapp://send?phone=' },
  { name: 'Spotify', scheme: 'spotify://', placeholder: 'spotify://' },
  { name: 'Google Maps', scheme: 'geo:', placeholder: 'geo:0,0?q=' },
];

const ShortcutForm: React.FC<ShortcutFormProps> = ({ initialData, existingShortcuts, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState<ShortcutFormData>({
    name: '',
    url: '',
    keys: [],
    type: 'website'
  });
  const [isRecording, setIsRecording] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name,
        url: initialData.url,
        keys: initialData.keys,
        type: initialData.type || 'website'
      });
    }
  }, [initialData]);

  // Check for duplicates whenever keys change
  const duplicateError = useMemo(() => {
    if (formData.keys.length === 0) return null;
    
    const currentKeyString = JSON.stringify(formData.keys);
    
    const duplicate = existingShortcuts.find(s => {
      // Don't compare with itself if editing
      if (initialData && s.id === initialData.id) return false;
      return JSON.stringify(s.keys) === currentKeyString;
    });

    if (duplicate) {
      return `Sequence already used by "${duplicate.name}"`;
    }
    return null;
  }, [formData.keys, existingShortcuts, initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!formData.name || !formData.url || formData.keys.length === 0) {
      setError("Please fill in all fields.");
      return;
    }

    if (duplicateError) {
      setError("Cannot save duplicate key sequence.");
      return;
    }
    
    // basic url formatting for websites
    let url = formData.url;
    if (formData.type === 'website' && !url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    onSubmit({ ...formData, url });
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold text-white">
            {initialData ? 'Edit Shortcut' : 'New Shortcut'}
          </h2>
          <button onClick={onCancel} className="text-slate-400 hover:text-white transition-colors">
            <X size={24} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          
          {/* Type Selector */}
          <div className="flex p-1 bg-slate-800 rounded-xl">
            <button
              type="button"
              onClick={() => setFormData(p => ({ ...p, type: 'website' }))}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all ${
                formData.type === 'website' 
                  ? 'bg-indigo-600 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Globe size={16} /> Website
            </button>
            <button
              type="button"
              onClick={() => setFormData(p => ({ ...p, type: 'app' }))}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium transition-all ${
                formData.type === 'app' 
                  ? 'bg-indigo-600 text-white shadow-lg' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Smartphone size={16} /> Mobile App
            </button>
          </div>

          {/* Name Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
              <Type size={16} /> Name
            </label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder={formData.type === 'website' ? "e.g. YouTube" : "e.g. Call Mom"}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              required
            />
          </div>

          {/* URL/URI Input */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-400 flex items-center gap-2">
              {formData.type === 'website' ? <Globe size={16} /> : <Smartphone size={16} />} 
              {formData.type === 'website' ? 'Website URL' : 'App URI Scheme'}
            </label>
            
            {formData.type === 'app' && (
              <div className="flex gap-2 mb-2 overflow-x-auto pb-2 scrollbar-thin">
                {COMMON_APPS.map(app => (
                  <button
                    key={app.name}
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, url: app.scheme }))}
                    className="px-3 py-1 bg-slate-800 border border-slate-700 rounded-full text-xs text-slate-300 hover:bg-slate-700 hover:text-white whitespace-nowrap transition-colors"
                  >
                    {app.name}
                  </button>
                ))}
              </div>
            )}

            <input
              type="text"
              value={formData.url}
              onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
              placeholder={formData.type === 'website' ? "youtube.com" : "app-scheme:// or tel:..."}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all font-mono text-sm"
              required
            />
            {formData.type === 'app' && (
              <p className="text-xs text-slate-500">
                Enter a URI scheme (e.g., <code className="bg-slate-800 px-1 rounded text-slate-400">whatsapp://</code>, <code className="bg-slate-800 px-1 rounded text-slate-400">tel:</code>) to launch native apps.
              </p>
            )}
          </div>

          {/* Key Recorder */}
          <div className="space-y-2">
             <KeyRecorder 
              keys={formData.keys}
              isRecording={isRecording}
              onToggleRecording={() => setIsRecording(!isRecording)}
              onChange={(keys) => setFormData(prev => ({ ...prev, keys }))}
            />
            {duplicateError && (
              <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 p-3 rounded-lg border border-red-400/20">
                <AlertCircle size={16} />
                <span>{duplicateError}</span>
              </div>
            )}
          </div>

          {error && !duplicateError && (
             <div className="text-red-400 text-sm text-center">{error}</div>
          )}

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              className="flex-1 py-3 rounded-xl font-medium text-slate-300 hover:bg-slate-800 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isRecording || !formData.name || !formData.url || formData.keys.length === 0 || !!duplicateError}
              className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-medium shadow-lg shadow-indigo-500/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition-all"
            >
              <Save size={18} />
              Save Shortcut
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ShortcutForm;