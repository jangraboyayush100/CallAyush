import React, { useState } from 'react';
import { Sparkles, Loader2, ArrowRight } from 'lucide-react';
import { suggestShortcut } from '../services/geminiService';
import { ShortcutFormData } from '../types';

interface AISuggestionProps {
  onSelect: (data: ShortcutFormData) => void;
  onClose: () => void;
}

const AISuggestion: React.FC<AISuggestionProps> = ({ onSelect, onClose }) => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError('');
    
    try {
      const result = await suggestShortcut(query);
      if (result) {
        onSelect(result);
        onClose();
      } else {
        setError('Could not generate a suggestion. Please try being more specific.');
      }
    } catch (err) {
      setError('Something went wrong. check your connection or API key.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md bg-slate-900 border border-slate-700 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        
        {/* Abstract bg shape */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative">
          <div className="flex items-center gap-2 mb-2 text-indigo-400">
            <Sparkles size={20} />
            <h3 className="font-semibold tracking-wide uppercase text-xs">AI Assistant</h3>
          </div>
          <h2 className="text-xl font-bold text-white mb-4">Generate Shortcut</h2>
          
          <p className="text-slate-400 text-sm mb-6">
            Describe what you want to open. The AI will suggest a name, URL, and a smart key sequence for you.
          </p>

          <form onSubmit={handleSearch}>
            <div className="relative">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="e.g., Open my favorite music playlist"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all pr-12"
                autoFocus
              />
              <button 
                type="submit"
                disabled={isLoading || !query.trim()}
                className="absolute right-2 top-2 p-1.5 bg-indigo-600 rounded-lg text-white disabled:opacity-50 hover:bg-indigo-500 transition-colors"
              >
                {isLoading ? <Loader2 size={18} className="animate-spin" /> : <ArrowRight size={18} />}
              </button>
            </div>
            {error && <p className="text-red-400 text-xs mt-3">{error}</p>}
          </form>
          
          <button 
            onClick={onClose}
            className="mt-6 w-full py-2 text-slate-400 hover:text-white text-sm transition-colors"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};

export default AISuggestion;