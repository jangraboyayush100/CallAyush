import React, { useEffect, useState } from 'react';
import { Keyboard, X } from 'lucide-react';
import { normalizeKey } from '../hooks/useKeySequence';

interface KeyRecorderProps {
  keys: string[];
  onChange: (keys: string[]) => void;
  isRecording: boolean;
  onToggleRecording: () => void;
}

const KeyRecorder: React.FC<KeyRecorderProps> = ({ keys, onChange, isRecording, onToggleRecording }) => {
  const [tempKeys, setTempKeys] = useState<string[]>(keys);

  useEffect(() => {
    if (!isRecording) {
      setTempKeys(keys);
      return;
    }

    const handleKeyDown = (e: KeyboardEvent) => {
      e.preventDefault();
      
      const key = normalizeKey(e.key);
      
      // Limit sequence length to 5 for sanity
      setTempKeys(prev => {
        if (prev.length >= 5) return prev;
        return [...prev, key];
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isRecording, keys]);

  const handleStop = () => {
    onChange(tempKeys);
    onToggleRecording();
  };

  const handleClear = () => {
    if (isRecording) {
      setTempKeys([]);
    } else {
      onChange([]);
      setTempKeys([]);
    }
  };

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-slate-400">Sequence</label>
        {isRecording && (
          <span className="text-xs text-red-400 animate-pulse font-bold uppercase tracking-wider">
            Recording...
          </span>
        )}
      </div>

      <div 
        className={`relative min-h-[60px] p-4 rounded-xl border-2 flex flex-wrap items-center gap-2 transition-all duration-300 ${
          isRecording 
            ? 'border-indigo-500 bg-indigo-500/10 shadow-[0_0_20px_rgba(99,102,241,0.3)]' 
            : 'border-slate-700 bg-slate-800'
        }`}
      >
        {(isRecording ? tempKeys : keys).length === 0 && (
          <div className="text-slate-500 text-sm flex items-center gap-2">
            <Keyboard size={16} />
            <span>{isRecording ? "Press keys to record..." : "No keys set"}</span>
          </div>
        )}

        {(isRecording ? tempKeys : keys).map((k, idx) => (
          <span 
            key={idx} 
            className="px-3 py-1.5 bg-slate-700 text-slate-100 rounded-lg font-mono text-sm border border-slate-600 shadow-sm"
          >
            {k}
          </span>
        ))}

        <div className="ml-auto flex gap-2">
           {(isRecording || keys.length > 0) && (
              <button
                onClick={handleClear}
                className="p-2 hover:bg-slate-600 rounded-full text-slate-400 hover:text-white transition-colors"
                title="Clear sequence"
                type="button"
              >
                <X size={16} />
              </button>
           )}
        </div>
      </div>

      <button
        type="button"
        onClick={isRecording ? handleStop : onToggleRecording}
        className={`mt-2 w-full py-2.5 rounded-lg font-medium transition-all duration-200 ${
          isRecording
            ? 'bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/25'
            : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/25'
        }`}
      >
        {isRecording ? 'Stop Recording' : (keys.length > 0 ? 'Re-record Sequence' : 'Start Recording')}
      </button>
      
      <p className="text-xs text-slate-500">
        Tip: You can use standard keys or special keys like Volume Up/Down (if supported by your device).
      </p>
    </div>
  );
};

export default KeyRecorder;