export interface Shortcut {
  id: string;
  name: string;
  url: string;
  keys: string[];
  type: 'website' | 'app';
  createdAt: number;
}

export interface ShortcutFormData {
  name: string;
  url: string;
  keys: string[];
  type: 'website' | 'app';
}

export enum RecorderState {
  IDLE = 'IDLE',
  RECORDING = 'RECORDING',
  LISTENING = 'LISTENING'
}