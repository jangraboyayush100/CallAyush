import React, { useState, useEffect } from 'react';
import { Plus, Command, Trash2, Edit2, Zap, ExternalLink, Keyboard, Sparkles, Activity, Pin, Smartphone, Globe } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { Shortcut, ShortcutFormData } from './types';
import { useKeySequence } from './hooks/useKeySequence';
import ShortcutForm from './components/ShortcutForm';
import AISuggestion from './components/AISuggestion';
import ConfirmDialog from './components/ConfirmDialog';

const App: React.FC = () => {
  // Load initial state from local storage or defaults
  const [shortcuts, setShortcuts] = useState<Shortcut[]>(() => {
    try {
      const saved = localStorage.getItem('keymaster-shortcuts');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isAIOpen, setIsAIOpen] = useState(false);
  const [editingShortcut, setEditingShortcut] = useState<Shortcut | undefined>(undefined);
  
  // To handle pre-filled data from AI
  const [prefillData, setPrefillData] = useState<ShortcutFormData | undefined>(undefined);

  // Initialize the key listener hook
  const { buffer, lastMatch } = useKeySequence(shortcuts);
  const [activeFlash, setActiveFlash] = useState<string | null>(null);

  // Modal State
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    localStorage.setItem('keymaster-shortcuts', JSON.stringify(shortcuts));
  }, [shortcuts]);

  useEffect(() => {
    if (lastMatch) {
      setActiveFlash(lastMatch.id);
      const timer = setTimeout(() => setActiveFlash(null), 1000);
      return () => clearTimeout(timer);
    }
  }, [lastMatch]);

  const handleSave = (data: ShortcutFormData) => {
    if (editingShortcut) {
      setShortcuts(prev => prev.map(s => s.id === editingShortcut.id ? { ...s, ...data } : s));
    } else {
      setShortcuts(prev => [...prev, { ...data, id: uuidv4(), createdAt: Date.now() }]);
    }
    setIsFormOpen(false);
    setEditingShortcut(undefined);
    setPrefillData(undefined);
  };

  const handleDeleteClick = (id: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Shortcut',
      message: 'Are you sure you want to delete this shortcut? This action cannot be undone.',
      onConfirm: () => {
        setShortcuts(prev => prev.filter(s => s.id !== id));
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleClearAllClick = () => {
    setConfirmModal({
      isOpen: true,
      title: 'Clear All Shortcuts',
      message: '⚠️ Are you sure you want to delete ALL shortcuts? This will permanently remove every configuration you have saved.',
      onConfirm: () => {
        setShortcuts([]);
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handleEdit = (shortcut: Shortcut) => {
    setEditingShortcut(shortcut);
    setIsFormOpen(true);
  };

  const handleAISelect = (data: ShortcutFormData) => {
    setPrefillData(data);
    setEditingShortcut(undefined); // ensure we are in 'create' mode
    setIsFormOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50 selection:bg-indigo-500/30 pb-20">
      
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <Command size={18} className="text-white" />
            </div>
            <h1 className="text-xl font-bold tracking-tight">KeyMaster</h1>
          </div>
          
          <div className="flex items-center gap-3">
             {/* Key Buffer Display (Debug/Visualizer) */}
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-900 rounded-md border border-slate-800">
               <span className="text-xs text-slate-500 uppercase tracking-wider font-semibold">Buffer</span>
               <div className="flex gap-1 h-5 items-center">
                 {buffer.length === 0 ? (
                   <span className="text-xs text-slate-600 italic">Waiting...</span>
                 ) : (
                   buffer.map((k, i) => (
                     <span key={i} className="text-xs font-mono text-indigo-400">{k}</span>
                   ))
                 )}
               </div>
            </div>

            <button
              onClick={() => setIsAIOpen(true)}
              className="flex items-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-indigo-400 rounded-lg text-sm font-medium transition-colors border border-slate-700/50"
            >
              <Sparkles size={16} />
              <span className="hidden sm:inline">AI Assist</span>
            </button>

            <button
              onClick={() => {
                setEditingShortcut(undefined);
                setPrefillData(undefined);
                setIsFormOpen(true);
              }}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-sm font-medium shadow-lg shadow-indigo-500/20 transition-all hover:scale-105"
            >
              <Plus size={18} />
              <span className="hidden sm:inline">New Shortcut</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8">
        
        {/* Persistence Status Bar */}
        <div className="mb-8 p-4 bg-indigo-900/20 border border-indigo-500/30 rounded-xl flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="p-2 bg-indigo-600/20 rounded-lg text-indigo-400">
            <Activity size={20} />
          </div>
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              Background Listening Active
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              For shortcuts to work, this tab must remain open. 
              <strong className="text-indigo-300 ml-1">Pin this tab</strong> in your browser to keep it active even when restarting.
            </p>
          </div>
          <button 
             className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-slate-300 transition-colors flex items-center gap-2"
             onClick={() => alert("Right-click the tab at the top of your browser and select 'Pin Tab' to prevent accidental closing.")}
          >
            <Pin size={12} />
            How to Pin?
          </button>
        </div>

        {/* Welcome State */}
        {shortcuts.length === 0 && (
          <div className="text-center py-20 px-4">
            <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-6 ring-4 ring-slate-800">
              <Keyboard size={40} className="text-slate-600" />
            </div>
            <h2 className="text-3xl font-bold text-white mb-2">Master your workflow</h2>
            <p className="text-slate-400 max-w-md mx-auto mb-8">
              Create custom key sequences to open your favorite apps instantly. 
              Try sequences like "Vol+, Vol+" or "G, M" for Gmail.
            </p>
            <button
              onClick={() => setIsFormOpen(true)}
              className="px-6 py-3 bg-white text-slate-950 font-semibold rounded-xl hover:bg-indigo-50 transition-colors shadow-xl"
            >
              Create First Shortcut
            </button>
          </div>
        )}

        {/* Shortcuts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {shortcuts.map(shortcut => (
            <div 
              key={shortcut.id}
              className={`group relative bg-slate-900/50 border border-slate-800 rounded-xl p-5 transition-all duration-300 hover:border-indigo-500/50 hover:bg-slate-900 ${
                activeFlash === shortcut.id ? 'ring-2 ring-green-500 bg-green-500/10' : ''
              }`}
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                    shortcut.type === 'app' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-blue-500/20 text-blue-400'
                  }`}>
                    {shortcut.type === 'app' ? <Smartphone size={20} /> : <Globe size={20} />}
                  </div>
                  <div className="overflow-hidden">
                    <h3 className="font-semibold text-white group-hover:text-indigo-400 transition-colors truncate">
                      {shortcut.name}
                    </h3>
                    <div className="flex items-center gap-1 text-xs text-slate-500 mt-1">
                      {shortcut.type === 'app' ? (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-950/50 border border-emerald-900 text-emerald-500 text-[10px] font-medium uppercase tracking-wide">
                          APP
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded bg-blue-950/50 border border-blue-900 text-blue-500 text-[10px] font-medium uppercase tracking-wide">
                          WEB
                        </span>
                      )}
                      <span className="truncate max-w-[120px]" title={shortcut.url}>{shortcut.url}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => handleEdit(shortcut)}
                    className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Edit2 size={14} />
                  </button>
                  <button 
                    onClick={() => handleDeleteClick(shortcut.id)}
                    className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-red-950/30 rounded-md transition-colors"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 items-center">
                {shortcut.keys.map((k, i) => (
                  <span 
                    key={i} 
                    className="px-2 py-1 bg-slate-800 border border-slate-700 rounded-md text-xs font-mono text-slate-300 shadow-sm"
                  >
                    {k}
                  </span>
                ))}
                
                {activeFlash === shortcut.id && (
                    <span className="ml-auto flex items-center gap-1 text-xs font-bold text-green-400 animate-pulse">
                        <Zap size={12} fill="currentColor" /> Active
                    </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Clear All Shortcuts Section */}
        {shortcuts.length > 0 && (
          <div className="mt-16 flex flex-col items-center border-t border-slate-800/50 pt-8">
            <button
              onClick={handleClearAllClick}
              className="flex items-center gap-2 px-4 py-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors text-sm font-medium border border-transparent hover:border-red-500/20"
            >
              <Trash2 size={16} />
              Clear All Shortcuts
            </button>
            <p className="text-xs text-slate-600 mt-2">
               This will remove all your saved key sequences locally.
            </p>
          </div>
        )}
      </main>

      {/* Modals */}
      {isFormOpen && (
        <ShortcutForm 
          initialData={editingShortcut ? editingShortcut : (prefillData ? { ...prefillData, id: '', createdAt: 0 } : undefined)}
          existingShortcuts={shortcuts}
          onSubmit={handleSave}
          onCancel={() => {
            setIsFormOpen(false);
            setEditingShortcut(undefined);
            setPrefillData(undefined);
          }}
        />
      )}

      {isAIOpen && (
        <AISuggestion 
          onSelect={handleAISelect}
          onClose={() => setIsAIOpen(false)}
        />
      )}

      <ConfirmDialog 
        isOpen={confirmModal.isOpen}
        title={confirmModal.title}
        message={confirmModal.message}
        onConfirm={confirmModal.onConfirm}
        onCancel={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};

export default App;