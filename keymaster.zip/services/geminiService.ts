import { GoogleGenAI, Type } from "@google/genai";
import { ShortcutFormData } from "../types";

// Helper to validate/format URL
const formatUrl = (url: string, type: 'website' | 'app'): string => {
  if (!url) return '';
  if (type === 'app') return url; // Trust the AI for URI schemes
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  return `https://${url}`;
};

export const suggestShortcut = async (query: string): Promise<ShortcutFormData | null> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("API Key not found in environment variables.");
      return null;
    }

    const ai = new GoogleGenAI({ apiKey });

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `User wants a keyboard shortcut for: "${query}". 
      Suggest a name, a valid full URL (including https://) OR an App URI scheme (like spotify://, whatsapp://, etc), and a sequence of 2-4 keys.
      Determine if it is a 'website' or 'app'.
      Example: "Open YouTube" -> Name: "YouTube", URL: "https://youtube.com", Keys: ["y", "t"], Type: "website"`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            url: { type: Type.STRING },
            keys: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            type: { type: Type.STRING, enum: ["website", "app"] }
          },
          required: ["name", "url", "keys", "type"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;

    const data = JSON.parse(text);
    const type = (data.type === 'app' || data.type === 'website') ? data.type : 'website';
    
    return {
      name: data.name,
      url: formatUrl(data.url, type),
      keys: data.keys.map((k: string) => k.toLowerCase()), // Normalize keys
      type: type
    };

  } catch (error) {
    console.error("Gemini suggestion failed:", error);
    return null;
  }
};