import { useEffect, useState, useCallback, useRef } from 'react';
import { Shortcut } from '../types';

export const normalizeKey = (key: string) => {
  if (key === ' ') return 'Space';
  if (key === 'AudioVolumeUp') return 'Vol+';
  if (key === 'AudioVolumeDown') return 'Vol-';
  if (key === 'AudioVolumeMute') return 'Mute';
  return key;
};

export const useKeySequence = (shortcuts: Shortcut[]) => {
  const [buffer, setBuffer] = useState<string[]>([]);
  const [lastMatch, setLastMatch] = useState<Shortcut | null>(null);
  const timeoutRef = useRef<number | null>(null);

  // Time in ms to wait before clearing the buffer if no new key is pressed
  const TIMEOUT_MS = 1500; 

  const resetBuffer = useCallback(() => {
    setBuffer([]);
  }, []);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    // Don't capture inputs if user is typing in a form field
    const target = e.target as HTMLElement;
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(target.tagName) || target.isContentEditable) {
      return;
    }

    const key = normalizeKey(e.key);

    // Reset timer
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    setBuffer(prev => {
      const newBuffer = [...prev, key];
      // Keep buffer size manageable, max 10 to cover reasonably long shortcuts
      if (newBuffer.length > 10) return newBuffer.slice(-10);
      return newBuffer;
    });

    timeoutRef.current = window.setTimeout(() => {
      resetBuffer();
    }, TIMEOUT_MS);

  }, [resetBuffer]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, [handleKeyDown]);

  // Check for matches whenever buffer changes
  useEffect(() => {
    if (buffer.length === 0) return;

    // We check if the *end* of the buffer matches any shortcut's sequence
    const match = shortcuts.find(s => {
      if (s.keys.length > buffer.length) return false;
      const bufferSlice = buffer.slice(-s.keys.length);
      return bufferSlice.every((k, i) => k.toLowerCase() === s.keys[i].toLowerCase());
    });

    if (match) {
      console.log("Shortcut matched:", match.name);
      setLastMatch(match);
      resetBuffer(); // Clear buffer immediately after match to prevent double triggers
      
      // Execute
      window.open(match.url, '_blank');
    }
  }, [buffer, shortcuts, resetBuffer]);

  return { buffer, lastMatch };
};